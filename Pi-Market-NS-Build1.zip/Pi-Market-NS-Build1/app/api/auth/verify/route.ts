import { NextResponse } from 'next/server';

export const runtime = 'nodejs';

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const accessToken = typeof body?.accessToken === 'string' ? body.accessToken.trim() : '';
    if (!accessToken) return NextResponse.json({ error: 'Missing accessToken' }, { status: 400 });

    const baseUrl = process.env.PI_API_BASE_URL || 'https://api.minepi.com';
    const response = await fetch(`${baseUrl}/v2/me`, {
      method: 'GET',
      headers: {
        Authorization: `Bearer ${accessToken}`,
        ...(process.env.PI_API_KEY ? { 'X-API-Key': process.env.PI_API_KEY } : {}),
      },
      cache: 'no-store',
    });

    const data = await response.json().catch(() => null);
    if (!response.ok) return NextResponse.json({ error: 'Pi token verification failed', details: data }, { status: response.status });

    const user = data?.user ?? data;
    if (!user?.uid || !user?.username) return NextResponse.json({ error: 'Pi verification response missing uid/username' }, { status: 502 });
    return NextResponse.json({ user: { uid: user.uid, username: user.username } });
  } catch {
    return NextResponse.json({ error: 'Authentication verification service error' }, { status: 500 });
  }
}
