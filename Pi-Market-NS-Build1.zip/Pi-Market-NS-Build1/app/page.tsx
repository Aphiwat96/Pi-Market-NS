import Script from 'next/script';
import AuthButton from '../components/AuthButton';

export default function Home() {
  return <>
    <Script src="https://sdk.minepi.com/pi-sdk.js" strategy="afterInteractive" onLoad={() => window.dispatchEvent(new Event('pi-sdk-ready'))} />
    <main className="page"><section className="card">
      <h1 className="brand">Pi Market-NS</h1>
      <p className="subtitle">Build 1 · Authentication Foundation</p>
      <AuthButton />
      <p className="small">เส้นทางจริง: Pi Browser → Pi SDK → Pi.authenticate() → Access Token → Backend → Pi /v2/me → Verified Pi UID</p>
    </section></main>
  </>;
}
