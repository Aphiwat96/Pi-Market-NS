import './globals.css';
import type { Metadata } from 'next';

export const metadata: Metadata = {
  title: 'Pi Market-NS',
  description: 'Pi Market-NS — Build 1 Authentication Foundation',
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="th"><body>{children}</body></html>;
}
