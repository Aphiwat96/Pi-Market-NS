export type PiUser = { uid: string; username: string };
export type PiAuthResult = { accessToken: string; user: PiUser };

declare global {
  interface Window {
    Pi?: {
      init: (options: { version: string; sandbox: boolean }) => void;
      authenticate: (scopes: string[], onIncompletePaymentFound: (payment: unknown) => void) => Promise<PiAuthResult>;
    };
  }
}
