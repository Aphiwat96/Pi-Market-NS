# Pi Market-NS — Build 1

Authentication Foundation for Pi Market-NS.

## Real authentication path
Pi Browser → Pi SDK → `Pi.authenticate()` → Access Token → Pi Market-NS Backend → Pi Platform API `GET /v2/me` → Verified Pi UID.

This project intentionally does not create fake users, fake Pi balances, fake orders, or fake payments.

## Environment
Copy `.env.example` to `.env.local` and set the Pi server configuration. Keep `PI_API_KEY` server-side only.

`NEXT_PUBLIC_PI_SANDBOX=true` for Pi Sandbox testing. Use `false` for production.

## Run

```bash
npm install
npm run dev
```

Then open the app in Pi Browser for the Pi SDK authentication flow.
