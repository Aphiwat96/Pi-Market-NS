'use client';

import { useEffect, useState } from 'react';
import type { PiUser } from '../lib/pi/types';

export default function AuthButton() {
  const [ready, setReady] = useState(false);
  const [busy, setBusy] = useState(false);
  const [verified, setVerified] = useState<PiUser | null>(null);
  const [message, setMessage] = useState('กำลังเตรียม Pi SDK…');

  useEffect(() => {
    const init = () => {
      if (!window.Pi) return;
      window.Pi.init({
        version: '2.0',
        sandbox: process.env.NEXT_PUBLIC_PI_SANDBOX === 'true',
      });
      setReady(true);
      setMessage('พร้อมเชื่อมต่อ Pi Authentication');
    };
    if (window.Pi) init();
    else window.addEventListener('pi-sdk-ready', init);
    const timer = window.setInterval(() => { if (window.Pi) init(); }, 250);
    return () => { window.removeEventListener('pi-sdk-ready', init); window.clearInterval(timer); };
  }, []);

  async function authenticate() {
    if (!window.Pi) { setMessage('ไม่พบ Pi SDK — กรุณาเปิดแอปผ่าน Pi Browser'); return; }
    setBusy(true); setMessage('กำลังขอการยืนยันจาก Pi…');
    try {
      const auth = await window.Pi.authenticate(['username'], () => undefined);
      const response = await fetch('/api/auth/verify', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ accessToken: auth.accessToken }),
      });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || 'Backend verification failed');
      setVerified(data.user);
      setMessage('ยืนยันตัวตนสำเร็จจาก Pi Platform API');
    } catch (error) {
      setVerified(null);
      setMessage(error instanceof Error ? error.message : 'Authentication failed');
    } finally { setBusy(false); }
  }

  return <>
    <div className="status">{message}{verified ? `\nUID: ${verified.uid}\nUsername: ${verified.username}` : ''}</div>
    <button className="btn" disabled={!ready || busy} onClick={authenticate}>
      {busy ? 'กำลังยืนยัน…' : 'เข้าสู่ระบบด้วย Pi'}
    </button>
  </>;
}
